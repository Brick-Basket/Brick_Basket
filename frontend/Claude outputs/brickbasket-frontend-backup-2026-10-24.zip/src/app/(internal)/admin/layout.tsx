import { AuthGuard } from "@/components/shell/auth-guard";
import { ProjectProvider } from "@/components/providers/project-provider";
import { AppShell } from "@/components/shell/app-shell";
import { ADMIN_ROUTES } from "@/lib/constants/routes";
import { STAFF_ROLES } from "@/lib/permissions/permissions";

/**
 * FRONTEND IMPLEMENTATION DECISION (originally this pass, see
 * docs/OPEN_QUESTIONS.md #62; updated by the "Project Management
 * Navigation and Persistent Project Selection" correction):
 *
 * This global topbar `ProjectSelector` used to render on every `/admin/*`
 * page via `AppShell`'s `showProjectSelector ?? true` default, back when
 * an audit of every admin page/adapter found zero real
 * `useProjectContext()` reads — every module needing one project at a
 * time (Schedule, DPR, Cost to Complete, MRC, GRN, Wastage, Stock,
 * Purchase Orders, RFQ, Requisitions, Store Requisitions, GSTR, Fixed
 * Assets, Tax Records, Bank, Payments, Invoices, ACE) had its own
 * dedicated, disconnected project filter instead. Showing this global one
 * on every page changed nothing on any of them — exactly the "no one
 * understands why Commercial Complex/Luxury Villa is showing" confusion
 * that got it turned off here.
 *
 * That's since been fixed for the three modules grouped under "Project
 * Management" in the sidebar (Schedule, DPR, Site Updates — see
 * `nav-config.ts`): their own project filters now read/write this same
 * `ProjectProvider` (`schedule-filters.tsx`, `dpr-filters.tsx`, and the
 * Site Updates admin page), and the selection persists across navigation
 * and page refreshes (see `project-provider.tsx`'s localStorage restore).
 * The remaining, still-disconnected modules listed above are unaffected —
 * that's a separate, larger piece of work, not part of this correction.
 *
 * This global topbar control stays off here deliberately, rather than
 * flipping back to `true`: each of the three Project Management pages
 * already surfaces its own accessible project switcher at the point it
 * actually matters (the control's own label/button shows the active
 * project), per that correction's "avoid a new banner/header, integrate
 * into the existing UI" requirement — turning this one back on globally
 * would just reintroduce one more, *redundant* selector above pages that
 * already have one, and a non-functional one above the many pages still
 * listed above that don't read it. It stays on for the customer Portal,
 * where `/dashboard/documents` genuinely reads it.
 */
export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <AuthGuard allowedRoles={STAFF_ROLES}>
      <ProjectProvider>
        <AppShell
          variant="admin"
          homeHref={ADMIN_ROUTES.home}
          homeLabel="Operations"
          showProjectSelector={false}
        >
          {children}
        </AppShell>
      </ProjectProvider>
    </AuthGuard>
  );
}
