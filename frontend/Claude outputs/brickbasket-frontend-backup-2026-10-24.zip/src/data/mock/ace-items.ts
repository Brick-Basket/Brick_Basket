import type { ACEItem } from "@/types/domain/ace-item";

/**
 * Mock/demo dataset only — never imported outside
 * src/lib/api/adapters/ace-adapter.ts. Covers all 3 mock projects and a
 * spread of categories, so both the category filter and the Requisition
 * form's project-scoped item picker have real, varied data to show.
 *
 * `uom` values updated to the predefined `ACEUnitOfMeasure` codes
 * (Document 2 correction — see `src/types/domain/ace-item.ts`'s header
 * comment); every previously free-text value here has a corresponding
 * code in `ACE_UOM_ORDER` (`src/components/ace/ace-uom-config.ts`), so no
 * row lost its original unit.
 */
export const mockACEItems: ACEItem[] = [
  {
    id: "ace_1",
    projectId: "proj_luxury_villa",
    category: "civil",
    itemDescription: "TMT Steel (Fe 500), 12mm",
    uom: "kg",
    rate: 68,
    createdAt: "2026-05-20T05:00:00.000Z",
    updatedAt: "2026-05-20T05:00:00.000Z",
  },
  {
    id: "ace_2",
    projectId: "proj_luxury_villa",
    category: "civil",
    itemDescription: "OPC 53-grade Cement",
    uom: "bag_50kg",
    rate: 420,
    createdAt: "2026-05-20T05:00:00.000Z",
    updatedAt: "2026-05-20T05:00:00.000Z",
  },
  {
    id: "ace_3",
    projectId: "proj_luxury_villa",
    category: "electrical",
    itemDescription: "2.5 sq.mm Copper Wiring Cable",
    uom: "meter",
    rate: 46,
    createdAt: "2026-05-21T05:00:00.000Z",
    updatedAt: "2026-05-21T05:00:00.000Z",
  },
  {
    id: "ace_4",
    projectId: "proj_luxury_villa",
    category: "plumbing_sanitary",
    itemDescription: "CPVC Pipe, 1 inch",
    uom: "meter",
    rate: 95,
    createdAt: "2026-05-21T05:00:00.000Z",
    updatedAt: "2026-05-21T05:00:00.000Z",
  },
  {
    id: "ace_5",
    projectId: "proj_luxury_villa",
    category: "finishing",
    itemDescription: "Vitrified Floor Tiles, 600x600mm",
    uom: "sq_ft",
    rate: 78,
    notes: "Reference brand: Kajaria or equivalent.",
    createdAt: "2026-05-22T05:00:00.000Z",
    updatedAt: "2026-05-22T05:00:00.000Z",
  },
  {
    id: "ace_6",
    projectId: "proj_commercial_complex",
    category: "civil",
    itemDescription: "TMT Steel (Fe 500), 16mm",
    uom: "kg",
    rate: 66,
    createdAt: "2026-04-10T05:00:00.000Z",
    updatedAt: "2026-04-10T05:00:00.000Z",
  },
  {
    id: "ace_7",
    projectId: "proj_commercial_complex",
    category: "civil",
    itemDescription: "M-Sand (river-sand alternative)",
    uom: "cu_ft",
    rate: 62,
    createdAt: "2026-04-10T05:00:00.000Z",
    updatedAt: "2026-04-10T05:00:00.000Z",
  },
  {
    id: "ace_8",
    projectId: "proj_commercial_complex",
    category: "mechanical",
    itemDescription: "HVAC Ducting, GI Sheet 24-gauge",
    uom: "sq_ft",
    rate: 340,
    createdAt: "2026-04-12T05:00:00.000Z",
    updatedAt: "2026-04-12T05:00:00.000Z",
  },
  {
    id: "ace_9",
    projectId: "proj_commercial_complex",
    category: "electrical",
    itemDescription: "MCB Distribution Board, 12-way",
    uom: "nos",
    rate: 2_450,
    createdAt: "2026-04-13T05:00:00.000Z",
    updatedAt: "2026-04-13T05:00:00.000Z",
  },
  {
    id: "ace_10",
    projectId: "proj_modern_residence",
    category: "finishing",
    itemDescription: "Interior Emulsion Paint",
    uom: "litre",
    rate: 310,
    createdAt: "2026-03-15T05:00:00.000Z",
    updatedAt: "2026-03-15T05:00:00.000Z",
  },
  {
    id: "ace_11",
    projectId: "proj_modern_residence",
    category: "plumbing_sanitary",
    itemDescription: "Sanitaryware — Wall-mounted WC Set",
    uom: "nos",
    rate: 12_500,
    notes: "Reference brand: Hindware or equivalent.",
    createdAt: "2026-03-16T05:00:00.000Z",
    updatedAt: "2026-03-16T05:00:00.000Z",
  },
  {
    id: "ace_12",
    projectId: "proj_modern_residence",
    category: "civil",
    itemDescription: "Red Clay Bricks, Class A",
    uom: "nos_1000",
    rate: 6_800,
    createdAt: "2026-03-16T05:00:00.000Z",
    updatedAt: "2026-03-16T05:00:00.000Z",
  },
];
