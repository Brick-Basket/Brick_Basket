"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { ImagePlaceholder } from "@/components/marketing/image-placeholder";
import { WatchVideoButton } from "@/components/marketing/watch-video-button";
import { useLanguage } from "@/components/providers/language-provider";
import { renderHighlighted } from "@/lib/i18n/highlight";
import { INTRO_VIDEO } from "@/lib/content/public-site";

/**
 * Home page hero — pulled out of `page.tsx` into its own client component
 * so the page itself can stay a Server Component (keeping its
 * `export const metadata`) while this piece reads `useLanguage()` for the
 * bilingual title/subtitle. See docs/OPEN_QUESTIONS.md #77.
 */
export function HeroSection({ id, className }: { id?: string; className?: string }) {
  const { t } = useLanguage();

  return (
    <section id={id} className={className}>
      <div>
        {/*
          FRONTEND FIX (Hindi text overlapping across lines — see
          docs/CHANGELOG.md for the full back-and-forth): `leading-tight`
          (1.25) genuinely overlapped; `leading-normal` (1.5) genuinely
          still overlapped (Devanagari matras/conjuncts/reph marks need
          more vertical room than a Latin-tuned ratio assumes, especially
          at this heading's bold weight and large size). `leading-loose`
          (2.0) was tried as a Tailwind utility class next but turned out
          not to be getting applied at all (a Tailwind JIT/caching quirk on
          a class that had never been used elsewhere in this codebase) —
          switching to an inline `style={{ lineHeight }}` fixed that
          reliability problem for good (no JIT/purge/cache step for the
          browser to apply an inline style through), but the first value
          tried that way (2.3) turned out to be the opposite problem: once
          it was actually rendering, it was confirmed (via the English
          version, where "Building Stronger Spaces" / "for a Better
          Tomorrow" rendered with a very visibly large gap) to be more
          space than this heading needs — too loose, not too tight.

          Settled here at 1.75 — comfortably past the 1.5 that was
          confirmed too tight for Devanagari, well short of the 2.3 that
          was confirmed too loose for English, aiming for the middle
          ground neither extreme hit. Still an inline style, not a
          Tailwind class, so the JIT-reliability issue above can't recur.
        */}
        <h1
          className="font-heading text-4xl font-extrabold text-ink md:text-5xl"
          style={{ lineHeight: 1.75 }}
        >
          {renderHighlighted(t("hero.title"))}
        </h1>
        <p className="mt-5 max-w-md text-ink-muted">{t("hero.subtitle")}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="#services" className={buttonVariants({ size: "lg" })}>
            {t("hero.exploreServices")} <ArrowRight className="h-4 w-4" />
          </Link>
          <WatchVideoButton embedUrl={INTRO_VIDEO.embedUrl} label={t("hero.watchVideo")} />
        </div>
      </div>
      <ImagePlaceholder
        alt="BrickBasket project showcase"
        src="/images/hero-building.jpg"
        sizes="(max-width: 768px) 100vw, 50vw"
        priority
      />
    </section>
  );
}
