/**
 * Project — minimal shape for now.
 *
 * Purpose: gives the Part 3 application shell (ProjectSelector, project
 * context) something real to switch between. This is intentionally a thin
 * slice of the eventual `Project` entity — almost every later module
 * (Contracts, Documents, Vendors, Supply Chain, Store, Schedule/DPR,
 * Finance) references a project by ID, and each of those parts will extend
 * this file with the fields it needs rather than duplicating a parallel
 * type. Not tied to one owning part in docs/MODULES.md for that reason.
 *
 * `progressPercentage` added in the Customer Module pass — the owner's
 * three-item scope for that module ("Payments", "Progress percentage",
 * "Progress photographs", relayed via WhatsApp, see docs/CHANGELOG.md)
 * named a project-wide completion percentage with no existing field or
 * computed aggregate anywhere in the app to back it (checked
 * `project-schedule.ts`'s `ScheduleActivity`/`ScheduleProgressEntry` —
 * those are per-activity, never rolled up to a project-wide number). This
 * pass adds it as a **plain manually-set field**, edited from the new
 * Customer detail screen by staff — FRONTEND IMPLEMENTATION DECISION,
 * flagged in docs/OPEN_QUESTIONS.md, since the owner didn't specify
 * whether it should instead be computed from Schedule activity completion.
 * A real backend may want to replace this with a computed value later.
 *
 * Backend ownership: persistence and the authoritative field set are
 * backend-owned once a real Project module/API exists.
 */
export interface Project {
  id: string;
  name: string;
  location: string;
  /** Distinguishes "my projects" for a customer session in the portal shell. */
  customerId?: string;
  /**
   * 0–100. Manually set by staff (Customer Module pass) — not computed
   * from Schedule activity. See docs/OPEN_QUESTIONS.md.
   */
  progressPercentage?: number;
}

/** Shape for `ProjectsAdapter.update` — intentionally narrow: only `progressPercentage` is editable through this app today. */
export type UpdateProjectInput = Partial<Pick<Project, "progressPercentage">>;
