# Customer Module — delivery package

This zip is a snapshot of every file that makes up the Customer Module (Customer CRUD +
Project `progressPercentage` tracking/audit trail), exactly as it already exists on your
machine at `E:\Brick_Basket\frontend`. Nothing in here is a NEW change — this module was
already built and already on your device; this pass only (a) wrote the documentation that
had never been synced for it, and (b) found one dead-code file (flagged below). Every file
below already exists at the matching path under `E:\Brick_Basket\frontend\` — paste over
only if you want to double-check/restore, not because anything changed.

## Files in this zip (paths are relative to `frontend/`)

- `src/types/domain/customer.ts`
- `src/types/domain/project.ts`
- `src/types/domain/project-progress-log.ts`
- `src/lib/api/adapters/customers-adapter.ts`
- `src/lib/api/adapters/projects-adapter.ts`
- `src/lib/utils/project-progress.ts`
- `src/hooks/use-customers.ts`
- `src/hooks/use-customer-id.ts` (pre-existing, unrelated — included only because it's
  imported by code in this module; see its own header comment)
- `src/hooks/use-projects.ts`
- `src/hooks/use-project-progress.ts`
- `src/components/customers/customer-project-progress.tsx`
- `src/components/customers/customer-detail.tsx`
- `src/components/customers/customer-form.tsx`
- `src/components/customers/customer-table.tsx`
- `src/components/customers/customer-filters.tsx`
- `src/components/projects/project-progress-summary.tsx` — **the one actually used**,
  imported by `src/app/(portal)/dashboard/projects/page.tsx`
- `src/components/portal/project-progress-summary.tsx` — **DEAD CODE.** Byte-for-byte
  duplicate of the file above. Confirmed via a full-codebase grep that nothing imports this
  copy. Safe to delete whenever convenient (see `docs/OPEN_QUESTIONS.md` #83) — included here
  only so nothing is silently dropped from this snapshot.
- `src/data/mock/customers.ts`
- `src/data/mock/projects.ts`
- `src/app/(internal)/admin/customers/page.tsx`
- `src/app/(internal)/admin/customers/new/page.tsx`
- `src/app/(internal)/admin/customers/[id]/page.tsx`
- `src/app/(internal)/admin/customers/[id]/edit/page.tsx`

## Small additions inside shared files (NOT full files — only these lines matter)

These three files are shared by many modules, so the zip does not include full copies of
them. Only the lines below belong to the Customer Module; they are already in place on your
device exactly as shown.

**`src/lib/permissions/permissions.ts`** — `PermissionKey` union gained:
```ts
| "customers:read"
| "customers:write"
```
...and `ROLE_PERMISSIONS.admin` / `ROLE_PERMISSIONS.project_manager` both include
`"customers:read"` and `"customers:write"` in their arrays.

**`src/components/shell/nav-config.ts`** — admin nav gained:
```ts
{ label: "Customers", href: ADMIN_ROUTES.customers, icon: UserCircle, permission: "customers:read" },
```

**`src/lib/constants/routes.ts`** — `ADMIN_ROUTES` gained:
```ts
customers: "/admin/customers",
```

## Documentation updated this pass

`docs/DATA_MODELS.md`, `docs/API_CONTRACTS.md`, `docs/ROUTES.md`, `docs/MODULES.md`,
`docs/ROLES_AND_PERMISSIONS.md`, `docs/CHANGELOG.md`, `docs/OPEN_QUESTIONS.md` (new rows
#79–#83) were all updated to describe this module for the first time, and have already been
pushed to `E:\Brick_Basket\frontend\docs\` and synced to this Claude Project.
