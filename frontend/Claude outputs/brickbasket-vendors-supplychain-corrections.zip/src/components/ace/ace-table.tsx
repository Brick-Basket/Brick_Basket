"use client";

import { DataTable, type DataTableColumn } from "@/components/domain/data-table";
import { CONTRACT_CATEGORY_CONFIG } from "@/components/contracts/contract-category-config";
import { ACE_UOM_CONFIG } from "@/components/ace/ace-uom-config";
import { formatINR } from "@/lib/utils/format";
import { useProjects } from "@/hooks/use-projects";
import type { ACEItem } from "@/types/domain/ace-item";

export function ACETable({
  items,
  startIndex = 0,
  sortBy,
  sortDir,
  onSortChange,
  onView,
}: {
  items: ACEItem[];
  /**
   * Document 2 correction: a leading serial-number column. `startIndex`
   * is the 0-based offset of this page's first row within the full
   * (unpaginated) result set — pass `(page - 1) * pageSize` so numbering
   * continues across pages instead of restarting at 1 on every page.
   */
  startIndex?: number;
  sortBy?: string;
  sortDir?: "asc" | "desc";
  onSortChange: (key: string) => void;
  /** Omit (pass `undefined`) for a read-only viewer — rows become non-interactive. */
  onView?: (item: ACEItem) => void;
}) {
  const { projects: allProjects } = useProjects();
  const indexById = new Map(items.map((item, idx) => [item.id, idx]));

  const columns: DataTableColumn<ACEItem>[] = [
    {
      key: "srNo",
      header: "Sr. No.",
      hideOnMobile: true,
      render: (i) => startIndex + (indexById.get(i.id) ?? 0) + 1,
    },
    {
      key: "itemDescription",
      header: "Item",
      sortKey: "itemDescription",
      render: (i) => (
        <div>
          <p className="font-medium text-ink">{i.itemDescription}</p>
          {i.notes && <p className="text-xs text-ink-muted">{i.notes}</p>}
        </div>
      ),
    },
    {
      key: "category",
      header: "Category",
      render: (i) => CONTRACT_CATEGORY_CONFIG[i.category].label,
    },
    {
      key: "project",
      header: "Project",
      render: (i) => allProjects.find((p) => p.id === i.projectId)?.name ?? "—",
    },
    {
      key: "uom",
      header: "UOM",
      hideOnMobile: true,
      render: (i) => ACE_UOM_CONFIG[i.uom].label,
    },
    {
      key: "rate",
      header: "Rate",
      sortKey: "rate",
      render: (i) => `${formatINR(i.rate)} / ${ACE_UOM_CONFIG[i.uom].label}`,
    },
  ];

  return (
    <DataTable columns={columns} rows={items} keyFor={(i) => i.id} sortBy={sortBy} sortDir={sortDir} onSortChange={onSortChange} onRowClick={onView} />
  );
}
