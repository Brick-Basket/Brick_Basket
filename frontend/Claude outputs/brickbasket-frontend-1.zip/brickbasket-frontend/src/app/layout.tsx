import type { Metadata, Viewport } from "next";
import { Poppins, Baloo_2 } from "next/font/google";
import localFont from "next/font/local";
import { AuthProvider } from "@/components/providers/auth-provider";
import "./globals.css";

// Secondary Font per docs/BRAND_GUIDELINES.md — confirmed body font.
const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-poppins",
  display: "swap",
});

// Primary Font per docs/BRAND_GUIDELINES.md — the real "Super Wonder" display
// face (logo wordmark, headlines, hero banners), supplied by the client as
// SuperWonder-Regular.ttf and self-hosted here. Resolves
// docs/OPEN_QUESTIONS.md #13 — Baloo 2 below now only backstops the one
// weight Super Wonder ships (Regular) for any heading that needs a heavier
// synthetic weight, and as the fallback face while this loads.
const superWonder = localFont({
  src: "./fonts/SuperWonder-Regular.ttf",
  weight: "400",
  variable: "--font-heading-primary",
  display: "swap",
});

// Backstop for the Primary Font — kept in the stack (see globals.css
// `--font-heading`) for any heading weight Super Wonder's single Regular
// file can't cover natively, and as the fallback face while it loads.
const headingFallback = Baloo_2({
  subsets: ["latin"],
  weight: ["600", "700", "800"],
  variable: "--font-heading-fallback",
  display: "swap",
});

// TBD — requires client confirmation: production domain. Placeholder lets
// Next resolve relative OG image URLs during local dev/preview builds.
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://www.brickbasket.co.in";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "BrickBasket — Building Stronger Spaces for a Better Tomorrow",
    template: "%s | BrickBasket",
  },
  description:
    "Premium construction and real estate solutions built on trust, transparency and quality.",
  openGraph: {
    type: "website",
    siteName: "BrickBasket",
    title: "BrickBasket — Building Stronger Spaces for a Better Tomorrow",
    description:
      "Premium construction and real estate solutions built on trust, transparency and quality.",
    images: [{ url: "/brand/icon-on-red.png", width: 512, height: 504, alt: "BrickBasket" }],
  },
  twitter: {
    card: "summary",
    title: "BrickBasket — Building Stronger Spaces for a Better Tomorrow",
    description:
      "Premium construction and real estate solutions built on trust, transparency and quality.",
    images: ["/brand/icon-on-red.png"],
  },
};

// FRONTEND IMPLEMENTATION DECISION (post-Part-20 fix): Next.js 14+ moved
// `themeColor` out of the `metadata` export into its own `viewport` export
// and warns ("Unsupported metadata themeColor is configured in metadata
// export") if it's left in `metadata`. Split out here — mirrors
// --brand-red; Next.js viewport config requires a literal, not a CSS var.
export const viewport: Viewport = {
  themeColor: "#e31e24",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`scroll-smooth ${poppins.variable} ${superWonder.variable} ${headingFallback.variable}`}
    >
      <body className="font-sans antialiased">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
